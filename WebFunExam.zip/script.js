function over(){
    document.querySelector("#mainimage").setAttribute('src', 'images/assets/succulents-2.jpg');
}

function out(){
    document.querySelector("#mainimage").setAttribute('src', 'images/assets/succulents-1.jpg');
}

function Hide(){
    document.querySelector('#policy').remove();
}
